using System;

namespace SimpleLibrary
{
    public class Calculator
    {
        // Public method - will remain unchanged
        public int Add(int a, int b)
        {
            return DoAddition(a, b);
        }

        // Private method - will be renamed
        private int DoAddition(int x, int y)
        {
            return x + y;
        }

        // Another public method
        public int Multiply(int a, int b)
        {
            return a * b;
        }
    }
}