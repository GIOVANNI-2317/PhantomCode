document.addEventListener('DOMContentLoaded', function() {
    // Initialize syntax highlighting for any code elements on the page
    if (typeof hljs !== 'undefined') {
        hljs.configure({
            languages: ['csharp']
        });
        document.querySelectorAll('pre code.language-csharp').forEach(block => {
            hljs.highlightElement(block);
        });
    }
    
    // Get necessary elements
    const form = document.getElementById('upload-form');
    const reuseForm = document.getElementById('reuse-form');
    const submitBtn = document.getElementById('submit-btn');
    const fileInput = document.getElementById('code_file');
    const codeInput = document.getElementById('code_input');
    
    // Update extension display based on output format selection
    const formatRadios = document.querySelectorAll('input[name="output_format"]');
    const extensionDisplay = document.getElementById('extension-display');
    
    if (formatRadios && extensionDisplay) {
        formatRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                if (this.value === 'source') {
                    extensionDisplay.textContent = '.cs';
                } else if (this.value === 'dll') {
                    extensionDisplay.textContent = '.dll';
                }
            });
        });
    }
    
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Enhance UX with hover effects on cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.classList.add('shadow');
            // Scale effect with smooth transition
            this.style.transform = 'translateY(-2px) scale(1.005)';
            this.style.transition = 'all 0.3s ease';
        });
        card.addEventListener('mouseleave', function() {
            this.classList.remove('shadow');
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
    
    // Apply hover effects to buttons
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            if (!this.disabled) {
                this.style.transform = 'translateY(-1px)';
                this.style.transition = 'all 0.2s ease';
            }
        });
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // File validation for any file inputs
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (this.files.length > 0) {
                const fileName = this.value;
                const extension = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
                
                if (extension !== 'cs' && extension !== 'txt') {
                    showToast('Errore', 'Seleziona un file .cs o .txt valido.', 'danger');
                    this.value = ''; // Clear the file input
                    return false;
                }
                
                // Show file name in a toast
                const shortName = this.files[0].name.length > 25 
                    ? this.files[0].name.substring(0, 22) + '...' 
                    : this.files[0].name;
                    
                showToast('File selezionato', `"${shortName}" pronto per l'offuscamento.`, 'info');
            }
        });
    });
    
    // Handle form submission - main upload form
    if (form) {
        form.addEventListener('submit', function(e) {
            // Only show loading if file is actually selected
            if (fileInput.files.length > 0 || document.getElementById('code_input').value.trim()) {
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Processing...';
                submitBtn.disabled = true;
                
                // Create a loading message with progress animation
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-info mt-3';
                alertDiv.role = 'alert';
                alertDiv.innerHTML = `
                    <div class="d-flex align-items-center">
                        <div class="spinner-border spinner-border-sm me-3" role="status"></div>
                        <div>
                            <strong>Offuscamento in corso...</strong>
                            <div class="progress mt-2" style="height: 10px;">
                                <div class="progress-bar progress-bar-striped progress-bar-animated" 
                                    role="progressbar" style="width: 0%"></div>
                            </div>
                        </div>
                    </div>`;
                
                // Add the loading message after the form
                form.parentNode.insertBefore(alertDiv, form.nextSibling);
                
                // Simulate progress
                const progressBar = alertDiv.querySelector('.progress-bar');
                let progress = 0;
                const interval = setInterval(() => {
                    // Slow down as we approach 90%
                    if (progress < 90) {
                        progress += Math.random() * 10;
                        progressBar.style.width = `${Math.min(progress, 90)}%`;
                    }
                }, 500);
                
                // Clear interval after form submission (page will navigate away)
                setTimeout(() => clearInterval(interval), 10000);
                
            } else {
                e.preventDefault();
                showToast('Errore', 'Inserisci il codice C# o carica un file prima di procedere.', 'danger');
            }
        });
    }
    
    // Handle form submission - reuse settings form
    if (reuseForm) {
        reuseForm.addEventListener('submit', function(e) {
            const formFileInput = this.querySelector('input[type="file"]');
            if (formFileInput.files.length > 0) {
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Processing...';
                submitBtn.disabled = true;
                
                // Create a loading message
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-info mt-3';
                alertDiv.role = 'alert';
                alertDiv.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Obfuscating your DLL with previous settings...';
                
                // Add the loading message
                this.parentNode.appendChild(alertDiv);
            } else {
                e.preventDefault();
                showToast('Errore', 'Seleziona un file DLL prima di procedere.', 'danger');
            }
        });
    }
    
    // Function to show toast messages
    function showToast(title, message, type = 'info') {
        // Create toast container if it doesn't exist
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        // Create toast
        const toastId = 'toast-' + Date.now();
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.id = toastId;
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        // Toast content
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <strong>${title}:</strong> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" 
                    data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        // Add to container
        toastContainer.appendChild(toast);
        
        // Initialize and show toast
        const bsToast = new bootstrap.Toast(toast, {
            animation: true,
            autohide: true,
            delay: 3000
        });
        bsToast.show();
        
        // Remove toast after it's hidden
        toast.addEventListener('hidden.bs.toast', function() {
            this.remove();
        });
    }
    
    // Check for download success message in URL hash
    if (window.location.hash === '#download-complete') {
        showToast('Download completato', 'Il tuo DLL offuscato è stato scaricato con successo!', 'success');
        // Clear hash
        window.location.hash = '';
    }
    
    // Enhanced UI for code input - C# syntax feedback
    if (codeInput) {
        codeInput.addEventListener('input', function() {
            // Simple C# syntax detection for visual feedback
            const code = this.value;
            
            if (code.includes('namespace') || code.includes('class') || 
                code.includes('using System') || code.includes('public') || 
                code.includes('private') || code.includes('void')) {
                
                this.classList.add('is-valid');
                this.classList.remove('is-invalid');
            } else if (code.trim().length > 10) {
                // If there's content but doesn't look like valid C#
                this.classList.add('is-invalid');
                this.classList.remove('is-valid');
            } else {
                // Clear validation if not enough to tell
                this.classList.remove('is-valid');
                this.classList.remove('is-invalid');
            }
        });
        
        // Add sample code button functionality
        const sampleCodeButton = document.getElementById('sample-code-btn');
        if (sampleCodeButton) {
            sampleCodeButton.addEventListener('click', function() {
                const sampleCode = `using System;
using System.Collections.Generic;

namespace SampleApp
{
    public class Calculator
    {
        private readonly int _maxHistory;
        private List<string> _calculationHistory;
        
        public Calculator(int maxHistory = 10)
        {
            _maxHistory = maxHistory;
            _calculationHistory = new List<string>();
            Initialize();
        }
        
        // Public method that will stay unchanged
        public double Add(double a, double b)
        {
            string operation = $"{a} + {b} = {a + b}";
            RecordOperation(operation);
            return a + b;
        }
        
        // Private method that will be obfuscated
        private void Initialize()
        {
            for (int i = 0; i < 3; i++)
            {
                _calculationHistory.Add($"System initialized: {DateTime.Now}");
            }
        }
        
        // Private helper method that will be obfuscated
        private void RecordOperation(string operation)
        {
            _calculationHistory.Add(operation);
            if (_calculationHistory.Count > _maxHistory)
            {
                _calculationHistory.RemoveAt(0);
            }
        }
    }
}`;
                codeInput.value = sampleCode;
                codeInput.classList.add('is-valid');
                
                // Trigger change to update UI
                const event = new Event('input');
                codeInput.dispatchEvent(event);
                
                showToast('Codice di esempio', 'Codice C# di esempio aggiunto nell\'editor.', 'success');
            });
        }
    }
});
