using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace GXApi
{
    public class API

    {
        [DllImport("bin\\Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void Initialize();

        [DllImport("bin\\Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void Attach();

        [DllImport("bin\\Xeno.dll", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetClients();

        [DllImport("bin\\Xeno.dll", CallingConvention = CallingConvention.StdCall)]
        public static extern void SetSettings(API.SigmaSigmaBoy settingID, int value);

        [DllImport("bin\\Xeno.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
        private static extern void Execute(byte[] scriptSource, string[] clientUsers, int numUsers);
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool FreeLibrary(IntPtr hModule);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr LoadLibrary(string lpFileName);
        private bool isInjected;
        private static void AutoInject(bool enable)
        {
            API.Initialize();
            API._autoInject = enable;
            API.SetSettings(API.SigmaSigmaBoy.AutoAttach, enable ? 1 : 0);
        }

        public static bool IsAutoInjectEnabled()
        {
            return API._autoInject;
        }
        public static bool isinjected;
        public void DestroyInject()
        {
            isInjected = false;
            IntPtr moduleHandle = GetModuleHandle("bin\\Xeno.dll");
            if (moduleHandle != IntPtr.Zero)
            {
                FreeLibrary(moduleHandle);
            }
            Reload();
        }

        private void Reload()
        {
            if (!isInjected)
            {
                LoadLibrary("bin\\Xeno.dll");
                isInjected = true;
            }
        }


        public static void Inject()
        {
            API.Initialize();
            API.Attach();
            Thread.Sleep(1000);
            string s = "\tgame:GetService(\"StarterGui\"):SetCore(\"SendNotification\", {\r\n\t\tTitle = \"[GX API]\",\r\n\t\tText = \"Injected!.\"\r\n\t})";
            List<API.ClientInfo> clientsList = API.GetClientsList();
            string[] array = (from c in clientsList
                              select c.name).ToArray<string>();
            API.Execute(Encoding.UTF8.GetBytes(s), array, array.Length);
        }



        public static void Execute(string scriptSource)
        {
            List<API.ClientInfo> clientsList = API.GetClientsList();
            string[] array = (from c in clientsList
                              select c.name).ToArray<string>();
            API.Execute(Encoding.UTF8.GetBytes(scriptSource), array, array.Length);
        }




        private static List<API.ClientInfo> GetClientsList()
        {
            List<API.ClientInfo> list = new List<API.ClientInfo>();
            IntPtr intPtr = API.GetClients();
            for (; ; )
            {
                API.ClientInfo clientInfo = Marshal.PtrToStructure<API.ClientInfo>(intPtr);
                bool flag = clientInfo.name == null;
                if (flag)
                {
                    break;
                }
                list.Add(clientInfo);
                intPtr += Marshal.SizeOf<API.ClientInfo>();
            }
            return list;
        }


        public static bool IsInjected()
        {
            bool result;
            try
            {
                List<API.ClientInfo> clientsList = API.GetClientsList();
                result = (clientsList.Count > 0);
            }
            catch
            {
                result = false;
            }
            return result;
        }
        public void CloseRoblox()
        {

            Process[] processesByName = Process.GetProcessesByName("RobloxPlayerBeta");
            foreach (Process process in processesByName)
            {
                process.Kill();
            }
        }
        public static bool IsRobloxOpen()
        {
            return Process.GetProcessesByName("RobloxPlayerBeta").Length != 0;
        }

        private static bool _autoInject;

        private struct ClientInfo
        {
            public string version;

            public string name;

            public int id;
        }

        public enum SigmaSigmaBoy
        {
            AutoAttach = 1
        }
    }
}