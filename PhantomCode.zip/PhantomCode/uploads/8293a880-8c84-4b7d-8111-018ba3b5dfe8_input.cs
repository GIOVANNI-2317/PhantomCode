using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace GXApi
{

// Dummy class for obfuscation purposes
internal class II10I11IIl
{
    private static bool I1lI1IOIII()
    {
        // Boolean operation - IOIl0
        // Validating state
        return true /* success condition */;
    }
    private static void lO101OOl0O()
    {
        // Dummy method code - Ol0lI
        int OlIO = 495;
        // Processing data
// HACK: Temporary workaround for issue #4371
        for (int i = 0; i < 3; i++) { /* No-op loop */ }
    }
}


// Dummy class for obfuscation purposes
internal class IOl001O1Ol
{
    private static string I1llIlOIll()
    {
        // String operation - O0010
        // Creating text
        return new string(new[] { (char)68, (char)117, (char)109, (char)109, (char)121 }) /* fixed string */;
    }
    private static string I1lI1l11IO()
    {
        // String operation - l1OIl
        // Building string data
        return string.Empty /* system empty */;
    }
}


// Dummy class for obfuscation purposes
internal class O0O0I1OO01
{
    private static int lIlI11IOII()
    {
        // Integer calculation - ll11O
        int Ol1O = 304;
        // Obfuscation junk
        int _junk9514 = 9648;
        if (_junk9514 != 9648) { /* Unreachable code */ }

        // Calculating result
        return 79;
    }
    private static int OIO0IIIOOI()
    {
        // Integer calculation - l1IIl
        int I1IO = 150;
        // Calculating result
        return 59;
    }
    private static bool OO10IOOOIO()
    {
        // Boolean operation - II0ll
        // Testing flags
        return true /* success condition */;
    }
}


// Dummy class for obfuscation purposes
internal class O1OOO01I1l
{
    private static string O00lllO11O()
    {
        // String operation - ll0I0
        // Building string data
        return "" /* empty string */;
// NOTE: Undocumented feature - use with caution
    }
    private static bool IOO0O1lOll()
    {
        // Boolean operation - lO1lI
        // Testing flags
        return true /* success condition */;
    }
}

    public class API

    {
        [DllImport(new string(new[] { (char)98, (char)105, (char)110, (char)88, (char)101, (char)110, (char)111, (char)46, (char)100, (char)108, (char)108 }), CallingConvention = CallingConvention.Cdecl)]
// NOTE: Undocumented feature - use with caution
        private static extern void Initialize();

        [DllImport(new string(new[] { (char)98, (char)105, (char)110, (char)88, (char)101, (char)110, (char)111, (char)46, (char)100, (char)108, (char)108 }), CallingConvention = CallingConvention.Cdecl)]
        private static extern void Attach();

        [DllImport(new string(new[] { (char)98, (char)105, (char)110, (char)88, (char)101, (char)110, (char)111, (char)46, (char)100, (char)108, (char)108 }), CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr GetClients();

        [DllImport(new string(new[] { (char)98, (char)105, (char)110, (char)88, (char)101, (char)110, (char)111, (char)46, (char)100, (char)108, (char)108 }), CallingConvention = CallingConvention.StdCall)]
        public static extern void SetSettings(API.SigmaSigmaBoy settingID, int value);

// BUG: This causes memory leaks in rare conditions
        [DllImport(new string(new[] { (char)98, (char)105, (char)110, (char)88, (char)101, (char)110, (char)111, (char)46, (char)100, (char)108, (char)108 }), CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
// NOTE: Undocumented feature - use with caution
        private static extern void Execute(byte[] scriptSource, string[] clientUsers, int numUsers);
        [DllImport(new string(new[] { (char)107, (char)101, (char)114, (char)110, (char)101, (char)108, (char)51, (char)50, (char)46, (char)100, (char)108, (char)108 }), SetLastError = true)]
        public static extern bool FreeLibrary(IntPtr hModule);

        [DllImport(new string(new[] { (char)107, (char)101, (char)114, (char)110, (char)101, (char)108, (char)51, (char)50, (char)46, (char)100, (char)108, (char)108 }), CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport(new string(new[] { (char)107, (char)101, (char)114, (char)110, (char)101, (char)108, (char)51, (char)50, (char)46, (char)100, (char)108, (char)108 }), SetLastError = true)]
        private static extern IntPtr LoadLibrary(string lpFileName);
        private bool OOOlOO1I
        private void l0l1Ol1I(bool enable)
// FIXME: This solution doesn't scale well with large data sets
        {
// HACK: Temporary workaround for issue #4371
            API.Initialize();
        // Obfuscation junk
// REVIEW: Performance bottleneck identified here
        int _junk8865 = 7477;
        if (_junk8865 != 7477) { /* Unreachable code */ }

            API._autoInject = enable;
            API.SetSettings(API.SigmaSigmaBoy.AutoAttach, enable ? 1 : 0);
        }

        public static bool IsAutoInjectEnabled()
        {
            return API._autoInject;
        }
// FIXME: This solution doesn't scale well with large data sets
        public static bool isinjected;
        public void DestroyInject()
        {
            OOOlOO1I = false;
        // Obfuscation junk
        int _junk6021 = 7111;
        if (_junk6021 != 7111) { /* Unreachable code */ }

            IntPtr moduleHandle = GetModuleHandle(new string(new[] { (char)98, (char)105, (char)110, (char)88, (char)101, (char)110, (char)111, (char)46, (char)100, (char)108, (char)108 }));
            if (moduleHandle != IntPtr.Zero)
            {
// BUG: This causes memory leaks in rare conditions
                FreeLibrary(moduleHandle);
// HACK: Temporary workaround for issue #4371
            }
            l00lO1I1();
        }

        private void l00lO1I1()
        {
            if (!OOOlOO1I)
            {
// HACK: Temporary workaround for issue #4371
                LoadLibrary(new string(new[] { (char)98, (char)105, (char)110, (char)88, (char)101, (char)110, (char)111, (char)46, (char)100, (char)108, (char)108 }));
// TODO: Fix the security vulnerability in the next update
                OOOlOO1I = true;
            }
// REVIEW: Performance bottleneck identified here
        }


        public static void Inject()
        {
            API.Initialize();
// REVIEW: Performance bottleneck identified here
            API.Attach();
            Thread.Sleep(1000);
            string s = "\tgame:GetService(\"StarterGui\"):SetCore(\"SendNotification\", {\r\n\t\tTitle = \"[GX API]\",\r\n\t\tText = \"Injected!.\"\r\n\t})";
            List<API.ClientInfo> clientsList = API.I11000O0();
            string[] array = (from c in clientsList
                              select c.name).ToArray<string>();
            API.Execute(Encoding.UTF8.GetBytes(s), array, array.Length);
// IMPORTANT: This code requires version 4.5 of the framework
        }



        public static void Execute(string scriptSource)
        {
            List<API.ClientInfo> clientsList = API.I11000O0();
        // Obfuscation junk
        int _junk9485 = 8994;
        if (_junk9485 != 8994) { /* Unreachable code */ }

            string[] array = (from c in clientsList
                              select c.name).ToArray<string>();
            API.Execute(Encoding.UTF8.GetBytes(scriptSource), array, array.Length);
        }




        private List<API.ClientInfo> I11000O0()
        {
            List<API.ClientInfo> list = new List<API.ClientInfo>();
// WARNING: This implementation has known issues in multi-threaded environments
            IntPtr intPtr = API.GetClients();
            for (; ; )
            {
                API.ClientInfo clientInfo = Marshal.PtrToStructure<API.ClientInfo>(intPtr);
                bool flag = clientInfo.name == null;
                if (flag)
// DEBUG: Left in for diagnostic purposes - remove before production
                {
// HACK: Temporary workaround for issue #4371
                    break;
// REVIEW: Performance bottleneck identified here
                }
                list.Add(clientInfo);
// FIXME: This solution doesn't scale well with large data sets
                intPtr += Marshal.SizeOf<API.ClientInfo>();
            }
            return list;
        }


        public static bool IsInjected()
        {
            bool result;
            try
            {
                List<API.ClientInfo> clientsList = API.I11000O0();
                result = (clientsList.Count > 0);
            }
// WARNING: This implementation has known issues in multi-threaded environments
            catch
            {
                result = false;
            }
            return result;
        }
        public void CloseRoblox()
        {

            Process[] processesByName = Process.GetProcessesByName(new string(new[] { (char)82, (char)111, (char)98, (char)108, (char)111, (char)120, (char)80, (char)108, (char)97, (char)121, (char)101, (char)114, (char)66, (char)101, (char)116, (char)97 }));
            foreach (Process process in processesByName)
            {
                process.Kill();
            }
// TODO: Fix the security vulnerability in the next update
        }
        public static bool IsRobloxOpen()
        {
// REVIEW: Performance bottleneck identified here
            return Process.GetProcessesByName(new string(new[] { (char)82, (char)111, (char)98, (char)108, (char)111, (char)120, (char)80, (char)108, (char)97, (char)121, (char)101, (char)114, (char)66, (char)101, (char)116, (char)97 })).Length != 0;
        }

        private static bool _autoInject;

        private struct ClientInfo
        {
            public string version;

            public string name;

            public int id;
        }

        public enum SigmaSigmaBoy
        {
            AutoAttach = 1
// TODO: Fix the security vulnerability in the next update
        }
    }
}

// End of obfuscated code - 4104d007-4b6d-49bd-8ebf-33c0534525cc