import os
import uuid
import re
import random
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def auto_fix_code_errors(code):
    """
    Tenta di correggere automaticamente gli errori comuni di sintassi in C#
    
    Args:
        code (str): Codice C# da correggere
        
    Returns:
        str: Codice corretto
    """
    # 1. Prima cerca e definisci le variabili con nomi confusi che potrebbero mancare
    # Cerca variabili usate ma non dichiarate - solo con I e l come richiesto dall'utente
    all_var_refs = re.findall(r'(?<!\w)([lI][lI]+)(?!\w|\s*=|\s*\()', code)
    
    # Rimuovi i duplicati mantenendo l'ordine
    var_refs = []
    for var in all_var_refs:
        if var not in var_refs:
            var_refs.append(var)
    
    # Cerca i metodi già presenti per non ridefinirli
    for var_name in var_refs:
        # Se non troviamo nessuna dichiarazione o assegnazione della variabile
        declaration_pattern = rf'(int|string|bool|double|object|var)\s+{var_name}\s*[=;]'
        assignment_pattern = rf'{var_name}\s*='
        if not re.search(declaration_pattern, code) and not re.search(assignment_pattern, code):
            # Crea una dichiarazione di variabile in un punto appropriato
            # Trova una classe nel codice
            class_match = re.search(r'class\s+\w+\s*{', code)
            if class_match:
                insert_pos = class_match.end()
                var_decl = f"\n    // Auto-fixed: Declared missing variable\n    private static int {var_name} = 0;\n"
                code = code[:insert_pos] + var_decl + code[insert_pos:]
    
    # 2. Corregge l'errore comune di metodi statici referenziati ma non implementati
    # Per esempio: stringhe che usano StringObfuscator.GetXXXX() ma il metodo non esiste
    
    # Estrai TUTTI i possibili metodi Get che potrebbero essere chiamati
    # Usa un pattern più ampio che catturi Get seguito da numeri
    all_get_methods = re.findall(r'(?<!\w)(Get\d+)(?=\(|\s*\()', code)
    
    # Rimuovi i duplicati mantenendo l'ordine
    method_refs = []
    for method in all_get_methods:
        if method not in method_refs:
            method_refs.append(method)
    
    # 3. Trova o crea la classe StringObfuscator
    obfuscator_class = re.search(r'internal static class StringObfuscator\s*{([^}]*)}', code)
    if not obfuscator_class:
        # Se la classe non esiste, la creiamo con una struttura base
        new_class = """
// Auto-fixed class for string obfuscation
internal static class StringObfuscator
{
    // Auto-generated methods will be added here
}
"""
        # Trova un posto appropriato per inserire la classe
        namespace_end = re.search(r'namespace\s+[\w\.]+\s*{', code)
        if namespace_end:
            insert_pos = namespace_end.end()
            code = code[:insert_pos] + new_class + code[insert_pos:]
        else:
            # Se non c'è namespace, aggiungiamo la classe alla fine
            code += new_class
        
        # Aggiorna il riferimento alla classe dopo averla creata
        obfuscator_class = re.search(r'internal static class StringObfuscator\s*{([^}]*)}', code)
    
    # 4. Per ogni metodo Get trovato, verificare se esiste e altrimenti crearlo
    if obfuscator_class:
        class_content = obfuscator_class.group(1)
        new_methods = []
        
        for method_name in method_refs:
            # Se il metodo non è già definito nella classe
            if f"public static string {method_name}()" not in code:
                # Crea un metodo fittizio che restituisce una stringa vuota
                dummy_method = f"""
    public static string {method_name}()
    {{
        // Auto-fixed method: returns empty string instead of throwing exception
        return "";
    }}"""
                new_methods.append(dummy_method)
        
        # Se abbiamo nuovi metodi da aggiungere, facciamolo una sola volta
        if new_methods:
            new_class_content = class_content + "\n" + "\n".join(new_methods) + "\n"
            code = code.replace(class_content, new_class_content)
    
    # 5. Correggi gli errori di sintassi comuni
    
    # Punto e virgola mancanti a fine istruzione (escludi commenti e direttive preprocessore)
    lines = code.split('\n')
    for i in range(len(lines)):
        line = lines[i].strip()
        if (line and not line.startswith('//') and not line.startswith('#') and 
            not line.startswith('}') and not line.startswith('{') and
            not line.endswith(';') and not line.endswith(',') and 
            not line.endswith('{') and not line.endswith('}') and 
            not line.endswith(':') and not line.endswith('"')):
            # Aggiungi punto e virgola alla fine della linea
            lines[i] += ";"
    
    code = '\n'.join(lines)
    
    # Parentesi graffe non bilanciate
    open_braces = code.count('{')
    close_braces = code.count('}')
    
    # Aggiungi parentesi di chiusura mancanti
    if open_braces > close_braces:
        code += '\n' + ('}' * (open_braces - close_braces)) + " // Auto-fixed: added missing closing braces"
    
    # 6. Correggi errori di namespace
    if "namespace" not in code and "class" in code:
        # Avvolgi il codice in un namespace se manca
        code = "namespace AutoFixedNamespace\n{\n" + code + "\n} // Auto-fixed: added missing namespace"
    
    return code

def obfuscate_csharp_code(input_path, output_folder, output_name, options):
    """
    Obfuscate C# source code with various techniques and optionally compile to DLL
    
    Args:
        input_path (str): Path to the input C# file
        output_folder (str): Path to the output folder
        output_name (str): Desired name for the output file (without extension)
        options (dict): Dictionary of obfuscation options
        
    Returns:
        tuple: (output_path, obfuscated_code_content, is_dll) or None if obfuscation failed
    """
    try:
        # Get absolute paths
        abs_input_path = os.path.abspath(input_path)
        
        # Determine output format (source or dll)
        output_format = options.get('output_format', 'source')
        is_dll = output_format == 'dll'
        extension = '.dll' if is_dll else '.cs'
        
        # Generate a unique filename for the output
        output_filename = f"{uuid.uuid4()}_{output_name}{extension}"
        output_path = os.path.join(output_folder, output_filename)
        abs_output_path = os.path.abspath(output_path)
        
        # For preview purposes, we'll need a temporary CS file regardless of output format
        temp_cs_path = os.path.join(output_folder, f"temp_{uuid.uuid4()}.cs")
        
        # Log options for debugging
        logger.debug(f"Obfuscating C# code at {abs_input_path} with options: {options}")
        logger.debug(f"Output format: {output_format}, Output path: {abs_output_path}")
        
        # Read the original C# source code
        with open(abs_input_path, 'r', encoding='utf-8', errors='ignore') as src_file:
            source_code = src_file.read()
        
        # Se auto_fix_errors è abilitato, tenta di correggere gli errori comuni
        if options.get('auto_fix_errors', False):
            logger.debug("Auto-fixing code errors is enabled")
            source_code = auto_fix_code_errors(source_code)
        
        # Apply obfuscation techniques based on selected options
        obfuscated_code = source_code
        
        # Parse and obfuscate the code
        if options.get('rename_private', False):
            obfuscated_code = rename_private_members(obfuscated_code, options.get('rename_pattern', 'confusing'))
            
        # Primo passaggio: aggiungi classi dummy e la classe StringObfuscator
        # È importante farlo prima dell'offuscamento delle stringhe
        if options.get('add_dummy_classes', False):
            obfuscated_code = add_dummy_classes(obfuscated_code, options.get('rename_pattern', 'confusing'))
            
        # Applica offuscamento stringhe direttamente in base all'opzione specifica
        if options.get('obfuscate_strings', False):
            obfuscated_code = obfuscate_strings(obfuscated_code)
            
        # Applica offuscamento del flusso di controllo in base all'opzione
        if options.get('obfuscate_control_flow', False):
            obfuscated_code = obfuscate_control_flow(obfuscated_code)
            
        # Aggiungi commenti di metadati fuorvianti se richiesto
        if options.get('add_metadata_comments', False):
            obfuscated_code = add_metadata_comments(obfuscated_code, options)
            
        # Add obfuscation marker
        timestamp = uuid.uuid4()
        obfuscation_level = options.get('obfuscation_level', 'medium').upper()
        obfuscated_code = f"""// Obfuscated with PhantomCode Obfuscator v 0.1.0 (BETA, Have much bugs)
// Obfuscation timestamp: {timestamp}
// Obfuscation level: {obfuscation_level}
// Options: {'; '.join([k for k, v in options.items() if v and k != 'obfuscation_level' and k != 'output_format'])}

{obfuscated_code}

// End of obfuscated code - {timestamp}
"""
        
        # Write the obfuscated code to the temporary CS file for preview
        with open(temp_cs_path, 'w', encoding='utf-8') as temp_file:
            temp_file.write(obfuscated_code)
            
        # If DLL format is requested, compile the obfuscated code
        if is_dll:
            # Save the obfuscated code to a temporary file for compilation
            try:
                # Compile to DLL using dotnet
                logger.debug(f"Compiling obfuscated code to DLL: {abs_output_path}")
                compilation_success = compile_to_dll(temp_cs_path, abs_output_path)
                
                if not compilation_success:
                    logger.error("Failed to compile to DLL, falling back to source code output")
                    # If compilation fails, fall back to source code
                    output_filename = f"{uuid.uuid4()}_{output_name}.cs"
                    output_path = os.path.join(output_folder, output_filename)
                    abs_output_path = os.path.abspath(output_path)
                    
                    with open(abs_output_path, 'w', encoding='utf-8') as dst_file:
                        dst_file.write(obfuscated_code)
                    
                    is_dll = False
                    
            except Exception as e:
                logger.error(f"Error compiling to DLL: {str(e)}")
                # If compilation fails, fall back to source code
                output_filename = f"{uuid.uuid4()}_{output_name}.cs"
                output_path = os.path.join(output_folder, output_filename)
                abs_output_path = os.path.abspath(output_path)
                
                with open(abs_output_path, 'w', encoding='utf-8') as dst_file:
                    dst_file.write(obfuscated_code)
                
                is_dll = False
        else:
            # Just write the source code to the output file
            with open(abs_output_path, 'w', encoding='utf-8') as dst_file:
                dst_file.write(obfuscated_code)
            
        logger.debug(f"Successfully created obfuscated output at {abs_output_path}")
        return output_path, obfuscated_code, is_dll
        
    except Exception as e:
        logger.error(f"Error during C# code obfuscation: {str(e)}")
        return None


def compile_to_dll(cs_file_path, output_path):
    """
    Compile a C# source file to a DLL
    
    Args:
        cs_file_path (str): Path to the C# source file
        output_path (str): Path for the output DLL file
        
    Returns:
        bool: True if compilation was successful, False otherwise
    """
    try:
        import subprocess
        import shutil
        import tempfile
        
        # Create a temporary project directory
        project_id = str(uuid.uuid4())[:8]
        project_dir = os.path.join(tempfile.gettempdir(), f"cs_obfuscator_temp_{project_id}")
        os.makedirs(project_dir, exist_ok=True)
        
        logger.debug(f"Created temporary project directory at {project_dir}")
        
        # Create a basic C# project file with simplified settings
        csproj_path = os.path.join(project_dir, "ObfuscatedLibrary.csproj")
        with open(csproj_path, 'w') as csproj:
            csproj.write("""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net6.0</TargetFramework>
    <OutputType>Library</OutputType>
    <LangVersion>10.0</LangVersion>
    <ImplicitUsings>disable</ImplicitUsings>
    <Nullable>disable</Nullable>
  </PropertyGroup>
</Project>
""")
        
        # Copy the CS file to the project directory as Class1.cs
        project_cs_path = os.path.join(project_dir, "Class1.cs")
        with open(cs_file_path, 'r', encoding='utf-8') as src, open(project_cs_path, 'w', encoding='utf-8') as dst:
            dst.write(src.read())
        
        # Try to restore the NuGet packages first
        logger.debug(f"Restoring NuGet packages for project at {project_dir}")
        restore_process = subprocess.run(
            ["dotnet", "restore", csproj_path],
            capture_output=True,
            text=True
        )
        
        if restore_process.returncode != 0:
            logger.error(f"Package restore failed: {restore_process.stderr}")
            # Continue anyway, as some simple projects might not need package restore
        
        # Build the project with dotnet CLI with detailed output
        logger.debug(f"Building project at {project_dir}")
        # Use verbose output to see more details about the build process
        build_process = subprocess.run(
            ["dotnet", "build", csproj_path, "-c", "Release", "-v", "n"],
            capture_output=True,
            text=True
        )
        
        # Log the output regardless of success
        logger.debug(f"Build stdout: {build_process.stdout}")
        
        if build_process.returncode != 0:
            logger.error(f"Build failed: {build_process.stderr}")
            
            # Let's try with an even simpler project file
            with open(csproj_path, 'w') as csproj:
                csproj.write("""<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>netstandard2.0</TargetFramework>
  </PropertyGroup>
</Project>
""")
            
            logger.debug("Retrying with simpler project file (netstandard2.0)")
            build_process = subprocess.run(
                ["dotnet", "build", csproj_path, "-c", "Release"],
                capture_output=True,
                text=True
            )
            
            if build_process.returncode != 0:
                logger.error(f"Second build attempt failed: {build_process.stderr}")
                return False
        
        # Find the DLL file
        dll_path = None
        bin_dirs = [
            os.path.join(project_dir, "bin", "Release", "net6.0"),
            os.path.join(project_dir, "bin", "Release", "netstandard2.0"),
            os.path.join(project_dir, "bin", "Release")
        ]
        
        for bin_dir in bin_dirs:
            if os.path.exists(bin_dir):
                logger.debug(f"Checking for DLLs in {bin_dir}")
                for file in os.listdir(bin_dir):
                    if file.endswith(".dll"):
                        dll_path = os.path.join(bin_dir, file)
                        logger.debug(f"Found DLL: {dll_path}")
                        break
                if dll_path:
                    break
        
        if not dll_path:
            logger.error("Could not find compiled DLL. Directory contents:")
            for bin_dir in bin_dirs:
                if os.path.exists(bin_dir):
                    logger.error(f"Contents of {bin_dir}: {os.listdir(bin_dir)}")
            return False
        
        # Copy the DLL to the output path
        logger.debug(f"Copying DLL from {dll_path} to {output_path}")
        shutil.copy2(dll_path, output_path)
        
        # Clean up temporary files
        try:
            shutil.rmtree(project_dir)
            logger.debug(f"Cleaned up temporary directory {project_dir}")
        except Exception as e:
            logger.warning(f"Failed to clean up temporary files: {e}")
        
        if os.path.exists(output_path):
            logger.debug(f"Successfully created DLL at {output_path}")
            return True
        else:
            logger.error(f"DLL was not created at {output_path}")
            return False
        
    except Exception as e:
        logger.error(f"Error during compilation: {str(e)}")
        # Print stack trace for debugging
        import traceback
        logger.error(traceback.format_exc())
        return False


def rename_private_members(code, pattern_type):
    """
    Rename private members in the code with obfuscated names based on pattern
    """
    # Define the patterns to match private fields and methods
    private_field_pattern = r'private\s+(?:readonly\s+)?(\w+(?:\<.+\>)?)\s+(\w+)\s*[;=]'
    private_method_pattern = r'private\s+(?:static\s+)?(?:async\s+)?(\w+(?:\<.+\>)?)\s+(\w+)\s*\('
    
    # Generate obfuscated names based on pattern type
    def generate_obfuscated_name(length=8):
        if pattern_type == 'confusing':
            # Ensure first character is a letter (not a number)
            # Utilizziamo caratteri molto simili visivamente per confondere l'analisi
            # Ma non esageriamo con la lunghezza per evitare errori
            length = min(length, 6)  # Limitiamo la lunghezza
            first_char = random.choice("Il")
            
            # Usa SOLO I e l come richiesto dall'utente, mai numeri
            chars = ["I", "l"]  # Solo I/l
            
            # Generate rest of the name with confusing characters (solo I e l)
            rest = ''.join(random.choice(chars) for _ in range(length-1))
            return first_char + rest
        elif pattern_type == 'descriptive':
            # Nomi che sembrano descrittivi ma non lo sono
            prefixes = ["temp", "var", "obj", "tmp", "val"]
            prefix = random.choice(prefixes)
            suffix = str(random.randint(1000, 9999))
            return prefix + suffix
        else:  # standard
            # Usa solo caratteri estremamente leggibili con prefisso sicuro
            length = min(length, 5)
            prefix = "_p"
            safe_chars = "abcdefgjkmnqrtuvwxyzABCDEFGJKMNQRTUVWXYZ"
            suffix = ''.join(random.choice(safe_chars) for _ in range(length))
            unique_id = str(random.randint(1000, 9999))
            return prefix + suffix + unique_id
    
    # Track renames to ensure consistency
    renames = {}
    
    # Rename private fields
    def replace_private_field(match):
        type_name = match.group(1)
        field_name = match.group(2)
        
        # Don't rename certain special fields
        if field_name.startswith('_') or field_name == 'value' or field_name.startswith('__'):
            return match.group(0)
            
        # Use existing rename if we've seen this name before
        if field_name not in renames:
            renames[field_name] = generate_obfuscated_name()
            
        new_name = renames[field_name]
        return f'private {type_name} {new_name}'
    
    # Rename private methods
    def replace_private_method(match):
        return_type = match.group(1)
        method_name = match.group(2)
        
        # Don't rename certain special methods
        if method_name.startswith('_') or method_name in ['Main', 'Dispose', 'Finalize'] or method_name.startswith('__'):
            return match.group(0)
            
        # Use existing rename if we've seen this name before
        if method_name not in renames:
            renames[method_name] = generate_obfuscated_name()
            
        new_name = renames[method_name]
        return f'private {return_type} {new_name}('
    
    # Apply the renames
    code = re.sub(private_field_pattern, replace_private_field, code)
    code = re.sub(private_method_pattern, replace_private_method, code)
    
    # Update references to renamed members
    for original_name, new_name in renames.items():
        # Only replace exact matches with word boundaries to avoid partial matches
        code = re.sub(r'\b' + re.escape(original_name) + r'\b', new_name, code)
    
    return code


def add_dummy_classes(code, pattern_type):
    """
    Add dummy classes and methods to the code, including a StringObfuscator class
    """
    # Dictionary per tenere traccia delle stringhe offuscate e dei loro metodi
    string_methods = {}
    # Tieni traccia dei nomi già utilizzati per variabili o metodi
    used_names = set()
    # Tieni traccia dei metodi Get già nel codice
    existing_get_methods = set()
    
    # Estrai i metodi Get che esistono già nel codice
    for get_method in re.finditer(r'public\s+static\s+string\s+(Get\d+)\(\)', code):
        existing_get_methods.add(get_method.group(1))
    
    # Estrai tutte le stringhe che devono essere offuscate
    def extract_strings(code):
        strings = []
        for match in re.finditer(r'"([^"\\]*(?:\\.[^"\\]*)*)"', code):
            string_literal = match.group(1)
            # Controlla se la stringa deve essere offuscata (stesso criterio di obfuscate_strings)
            if (string_literal and len(string_literal) >= 3 and 
                not re.search(r'\{[^\}]*\}', string_literal) and '{' not in string_literal and
                '\\' not in string_literal and ' ' not in string_literal and
                not any(ord(c) > 127 for c in string_literal)):
                strings.append(string_literal)
        return strings
    
    # Genera nomi unici per classi e metodi basati sul pattern_type
    def generate_name(length=6, prefix="_x"):
        # Nomi brevi per evitare errori
        length = min(length, 6)
        
        # Tenta di generare un nome unico
        for _ in range(10):  # limite di tentativi
            if pattern_type == 'confusing':
                # Per classi e metodi dummy usiamo SOLO I e l, mai numeri
                first_char = random.choice("Il")
                # Array con solo I e l
                chars = ["I", "l"]  # Solo I/l, mai numeri
                name = first_char + ''.join(random.choice(chars) for _ in range(length-1))
                # Non usiamo numeri nel suffisso, solo stringhe di I e l
                unique_suffix = ''.join(random.choice(chars) for _ in range(2))
                full_name = name + unique_suffix
            elif pattern_type == 'descriptive':
                # Nomi che sembrano descrivere funzionalità ma sono ingannevoli
                fake_names = [
                    "Helper", "Utility", "Manager", "Handler", "Provider",
                    "Factory", "Builder", "Controller", "Service", "Cache"
                ]
                prefix = random.choice(fake_names)
                suffixes = ["Utils", "Data", "Logic", "Impl", "Core"]
                suffix = random.choice(suffixes)
                full_name = prefix + suffix + str(random.randint(1, 9))
            else:  # standard
                # Usa solo caratteri molto chiari
                safe_chars = "abcdefgjkmnqrtuvwxyzABCDEFGJKMNQRTUVWXYZ"
                suffix = ''.join(random.choice(safe_chars) for _ in range(length))
                unique_id = str(random.randint(1000, 9999))
                full_name = prefix + suffix + unique_id
            
            # Se il nome non è già usato, usalo e aggiungilo alla lista
            if full_name not in used_names:
                used_names.add(full_name)
                return full_name
        
        # Se dopo diversi tentativi non abbiamo trovato un nome unico,
        # ne creiamo uno con un suffisso numerico molto specifico
        return prefix + "_unique_" + str(uuid.uuid4())[:8]
    
    # Genera un nome Get unico che non è già nel codice
    def generate_get_method_name():
        for _ in range(10):  # limite di tentativi
            method_name = f"Get{random.randint(1000, 9999)}"
            if method_name not in existing_get_methods and method_name not in used_names:
                existing_get_methods.add(method_name)
                used_names.add(method_name)
                return method_name
        
        # Fallback con UUID se necessario
        return f"Get{str(uuid.uuid4())[:8]}"
    
    # Get namespace of the original code
    namespace_match = re.search(r'namespace\s+([\w\.]+)', code)
    namespace = namespace_match.group(1) if namespace_match else "ObfuscatedCode"
    
    # Estrai tutte le stringhe che richiedono offuscamento
    strings_to_obfuscate = extract_strings(code)
    
    # Genera metodi per la classe StringObfuscator
    string_obfuscator_methods = []
    
    # Crea un metodo per ogni stringa unica da offuscare
    for string_literal in set(strings_to_obfuscate):
        method_name = generate_get_method_name()
        var_name = f"s{random.randint(1000, 9999)}"
        
        # Crea un metodo che ritorna la stringa costante
        method_body = f"""
        // Metodo per restituire stringa offuscata
        string {var_name} = "{string_literal}";
        return {var_name};"""
        
        # Aggiungi il metodo alla classe StringObfuscator
        string_obfuscator_methods.append(f"""    public static string {method_name}()
    {{{method_body}
    }}""")
        
        # Memorizza l'associazione tra stringa e metodo
        string_methods[string_literal] = method_name
    
    # Crea la classe StringObfuscator
    string_obfuscator_class = f"""
// Classe per offuscamento stringhe
internal static class StringObfuscator
{{
{os.linesep.join(string_obfuscator_methods)}
}}
"""
    
    # Generate dummy class templates
    dummy_classes = []
    
    # Verifica se la classe StringObfuscator esiste già
    if not re.search(r'internal static class StringObfuscator', code):
        dummy_classes.append(string_obfuscator_class)  # Aggiungi la classe solo se non esiste
    
    # Crea un numero maggiore di classi dummy
    for _ in range(random.randint(3, 5)):
        class_name = generate_name()
        methods = []
        
        # Aggiungi più metodi per classe
        for _ in range(random.randint(2, 4)):
            method_name = generate_name(prefix="_m")
            # Variamo i tipi di ritorno
            return_type = random.choice(['void', 'int', 'string', 'bool', 'double'])
            
            # Creiamo codice più vario ma sempre sicuro
            if return_type == 'void':
                # Metodo void con più operazioni
                var1 = generate_name(3, "tmp")
                var2 = generate_name(3, "str")
                var3 = generate_name(3, "tmp")
                
                method_body = f"""
        // Metodo utility
        int {var1} = {random.randint(1, 1000)};
        string {var2} = "Sample{random.randint(1, 100)}";
        // Operazione senza effetto
        if ({var3} > 0) {{ /* Non fa nulla */ }}"""
            
            elif return_type == 'int':
                # Metodo int con calcolo più complesso
                var1 = generate_name(3, "a")
                var2 = generate_name(3, "b")
                
                method_body = f"""
        // Calcolo numerico
        int {var1} = {random.randint(1, 50)};
        int {var2} = {random.randint(1, 50)};
        return {random.randint(1, 100)}; // Valore costante"""
            
            elif return_type == 'string':
                # Metodo string che usa StringObfuscator
                if string_methods:
                    # Seleziona un metodo esistente per evitare errori
                    string_method = random.choice(list(string_methods.values()))
                    method_body = f"""
        // Recupera stringa da StringObfuscator
        return StringObfuscator.{string_method}();"""
                else:
                    method_body = f"""
        // Genera stringa semplice
        return "Value{random.randint(1, 100)}";"""
            
            elif return_type == 'bool':
                # Metodo boolean con logica
                var_name = generate_name(3, "val")
                
                method_body = f"""
        // Verifica condizione
        int {var_name} = {random.randint(1, 100)};
        // Ritorna valore costante
        return {random.choice(['true', 'false'])};"""
            
            else:  # double
                # Metodo double con calcolo
                var_name = generate_name(3, "d")
                
                method_body = f"""
        // Calcolo double
        double {var_name} = {random.randint(1, 100)}.{random.randint(1, 99)};
        return {random.randint(1, 10)}.{random.randint(1, 99)};"""
            
            # Aggiungi il metodo con sintassi pulita
            methods.append(f"""    private static {return_type} {method_name}()
    {{{method_body}
    }}""")
        
        # Create dummy class with methods
        dummy_class = f"""
// Dummy class for obfuscation purposes
internal class {class_name}
{{
{os.linesep.join(methods)}
}}
"""
        dummy_classes.append(dummy_class)
    
    # Find the position to insert dummy classes - after the namespace declaration
    # but before the end of the file
    if namespace_match:
        namespace_pos = namespace_match.end()
        # Find the opening brace after namespace declaration
        brace_match = re.search(r'\{', code[namespace_pos:])
        if brace_match:
            insert_pos = namespace_pos + brace_match.end()
            before = code[:insert_pos]
            after = code[insert_pos:]
            code = before + os.linesep + os.linesep.join(dummy_classes) + after
        else:
            # If can't find proper position, just append at the end
            code += os.linesep + os.linesep.join(dummy_classes)
    else:
        # If no namespace, append at the end
        code += os.linesep + os.linesep.join(dummy_classes)
    
    return code


def obfuscate_strings(code):
    """
    Obfuscate string literals in the code
    """
    # Tieni traccia di tutti i metodi Get creati per evitare collisioni
    generated_methods = set()
    string_to_method = {}
    string_obfuscator_methods = []
    
    def encode_string(match):
        string_literal = match.group(1)
        
        # In tutti questi casi, mantieni le stringhe originali per evitare problemi
        # Non offuscare stringhe vuote o molto corte
        if not string_literal or len(string_literal) < 3:
            return match.group(0)
            
        # Non offuscare stringhe che sembrano specificatori di formato
        if re.search(r'\{[^\}]*\}', string_literal) or '{' in string_literal:
            return match.group(0)
            
        # Non offuscare stringhe con escape sequences
        if '\\' in string_literal:
            return match.group(0)
            
        # Non offuscare stringhe che contengono spazi (potrebbero essere messaggi di errore)
        if ' ' in string_literal:
            return match.group(0)
            
        # Non offuscare stringhe con caratteri non ASCII
        if any(ord(c) > 127 for c in string_literal):
            return match.group(0)
        
        # Riutilizza lo stesso metodo per stringhe identiche
        if string_literal in string_to_method:
            return f"StringObfuscator.{string_to_method[string_literal]}()"
        
        # Crea un nuovo metodo con un nome unico
        while True:
            method_name = f"Get{random.randint(1000, 9999)}"
            if method_name not in generated_methods:
                generated_methods.add(method_name)
                break
        
        # Registra l'associazione tra stringa e metodo
        string_to_method[string_literal] = method_name
        
        # Crea il metodo nella classe StringObfuscator
        method_body = f"""
    public static string {method_name}()
    {{
        // Metodo per restituire stringa offuscata
        return "{string_literal}";
    }}"""
        string_obfuscator_methods.append(method_body)
        
        # Restituisci l'invocazione del metodo
        return f"StringObfuscator.{method_name}()"
    
    # First protect string interpolation by replacing them temporarily
    # Use a simple approach with a unique prefix that won't occur in normal code
    interpolation_marker = "INTERP_MARKER_"
    interpolation_dict = {}
    counter = 0
    
    # First pass: find all interpolated strings and store them
    def protect_interpolation(match):
        nonlocal counter
        original = match.group(0)
        marker = f"{interpolation_marker}{counter}"
        interpolation_dict[marker] = original
        counter += 1
        return marker
    
    # Protect interpolated strings
    protected_code = re.sub(r'\$"[^"]*(?:\\.[^"]*)*"', protect_interpolation, code)
    
    # Second pass: obfuscate normal strings
    obfuscated_code = re.sub(r'"([^"\\]*(?:\\.[^"\\]*)*)"', encode_string, protected_code)
    
    # Third pass: restore interpolated strings
    for marker, original in interpolation_dict.items():
        obfuscated_code = obfuscated_code.replace(marker, original)
    
    # Quarto passaggio: aggiungi la classe StringObfuscator con i metodi generati
    if string_obfuscator_methods:
        # Verifica se la classe StringObfuscator esiste già
        obfuscator_class = re.search(r'internal static class StringObfuscator\s*{([^}]*)}', obfuscated_code)
        
        if obfuscator_class:
            # Se esiste, aggiungi i metodi alla classe esistente
            class_content = obfuscator_class.group(1)
            new_class_content = class_content + "\n" + "\n".join(string_obfuscator_methods)
            # Sostituisci il contenuto della classe con quello nuovo
            obfuscated_code = obfuscated_code.replace(class_content, new_class_content)
        else:
            # Altrimenti, crea una nuova classe StringObfuscator
            string_obfuscator_class = f"""
// Classe per offuscamento stringhe
internal static class StringObfuscator
{{
{os.linesep.join(string_obfuscator_methods)}
}}
"""
            # Trova il posto migliore per inserire la classe
            namespace_match = re.search(r'namespace\s+([\w\.]+)', obfuscated_code)
            if namespace_match:
                namespace_pos = namespace_match.end()
                # Trova la parentesi graffa dopo la dichiarazione del namespace
                brace_match = re.search(r'\{', obfuscated_code[namespace_pos:])
                if brace_match:
                    insert_pos = namespace_pos + brace_match.end()
                    obfuscated_code = obfuscated_code[:insert_pos] + os.linesep + string_obfuscator_class + obfuscated_code[insert_pos:]
                else:
                    # Se non trova la posizione giusta, aggiungi alla fine
                    obfuscated_code += os.linesep + string_obfuscator_class
            else:
                # Se non c'è namespace, aggiungi alla fine
                obfuscated_code += os.linesep + string_obfuscator_class
    
    return obfuscated_code


def obfuscate_control_flow(code):
    """
    Add control flow obfuscation to the code (adding junk conditions, etc.)
    """
    # Find method bodies
    method_pattern = r'((?:public|private|protected|internal)\s+(?:static\s+)?(?:\w+(?:\<.+\>)?)\s+\w+\s*\([^)]*\)\s*{)([^}]+)(})'
    
    def obfuscate_method_body(match):
        method_header = match.group(1)
        method_body = match.group(2)
        method_close = match.group(3)
        
        # Add junk conditional blocks
        lines = method_body.split('\n')
        new_lines = []
        
        # Track if we're inside a complex structure or statement
        in_complex_init = False
        brace_depth = 0
        in_return_statement = False
        in_attribute_section = False
        in_for_loop = False
        in_using_statement = False
        
        for i, line in enumerate(lines):
            line_stripped = line.strip()
            
            # Track special sections
            if '[' in line_stripped and not line_stripped.endswith(';'):
                in_attribute_section = True
            elif in_attribute_section and ']' in line_stripped:
                in_attribute_section = False
                
            # Track for loops
            if line_stripped.startswith('for ') and not line_stripped.endswith(';'):
                in_for_loop = True
            elif in_for_loop and line_stripped.endswith(')'):
                in_for_loop = False
                
            # Track using statements
            if line_stripped.startswith('using ') and '(' in line_stripped and not line_stripped.endswith(';'):
                in_using_statement = True
            elif in_using_statement and line_stripped.endswith(')'):
                in_using_statement = False
                
            # Track return statements that might span multiple lines
            if 'return ' in line_stripped and not line_stripped.endswith(';'):
                in_return_statement = True
            elif in_return_statement and line_stripped.endswith(';'):
                in_return_statement = False
                
            new_lines.append(line)
            
            # Skip if in any special section that shouldn't be interrupted
            if (in_return_statement or in_attribute_section or 
                in_for_loop or in_using_statement):
                continue
                
            # Track complex structure state more carefully
            if '{' in line:
                brace_depth += line.count('{')
            if '}' in line:
                brace_depth -= line.count('}')
                
            # Check for complex structure or initialization
            if (line_stripped.endswith('{') or
                '= new' in line_stripped or 
                '= {' in line_stripped or
                '=>' in line_stripped or    # Lambda expressions
                line_stripped.endswith('(') or  # Opening parenthesis
                '?' in line_stripped or     # Conditional expressions
                'params' in line_stripped): # Variable arguments
                in_complex_init = True
            elif brace_depth == 0:
                in_complex_init = False
            
            # Add junk conditionals with strong safety checks
            # Ridotta la probabilità per evitare errori 
            if (line_stripped and 
                line_stripped.endswith(';') and  # Deve terminare con punto e virgola
                not line_stripped.startswith('//') and 
                not in_complex_init and
                not in_return_statement and
                brace_depth > 0 and  # Deve essere dentro un blocco di codice
                not any(x in line_stripped for x in [
                    'case ', 'switch', '= {', '= new', 'return ', '=>', 
                    'throw ', 'continue', 'break', '[', ']', '?', ':', 
                    'catch', 'finally', '*', '/=', '%=', '+=', '-=', 
                    'params', 'ref', 'in ', 'out ']) and
                random.random() < 0.05):  # Probabilità molto ridotta
                
                # Genera un nome sicuro senza caratteri ambigui
                junk_var = f"_junk{random.randint(1000, 9999)}"
                junk_value = random.randint(1, 100)  # Valore minore 
                
                # Junk code più semplice che non dovrebbe causare problemi
                dummy_condition = f"        // Junk variable\n        int {junk_var} = {junk_value};\n"
                new_lines.append(dummy_condition)
        
        return method_header + '\n'.join(new_lines) + method_close
    
    code = re.sub(method_pattern, obfuscate_method_body, code)
    
    return code


def add_metadata_comments(code, options):
    """
    Add misleading metadata comments to confuse readers
    """
    # Create misleading comments
    dummy_comments = [
        "// IMPORTANT: This code requires version 4.5 of the framework",
        "// TODO: Fix the security vulnerability in the next update",
        "// WARNING: This implementation has known issues in multi-threaded environments",
        "// NOTE: Undocumented feature - use with caution",
        "// HACK: Temporary workaround for issue #4371",
        "// DEBUG: Left in for diagnostic purposes - remove before production",
        "// REVIEW: Performance bottleneck identified here",
        "// BUG: This causes memory leaks in rare conditions",
        "// FIXME: This solution doesn't scale well with large data sets",
        "// XXX: Critical business logic - do not modify without approval"
    ]
    
    # Add dummy comments randomly throughout the code
    lines = code.split('\n')
    for i in range(len(lines)):
        if random.random() < 0.1 and lines[i].strip() and not lines[i].strip().startswith('//'):
            lines[i] = random.choice(dummy_comments) + '\n' + lines[i]
    
    # Generate fake version information
    fake_version = f"{random.randint(1, 5)}.{random.randint(0, 9)}.{random.randint(0, 9)}.{random.randint(1000, 9999)}"
    
    # Add metadata header
    header = f"""// <auto-generated>
//     This code was generated by the C# Obfuscator Tool.
//     Runtime Version: {fake_version}
//
//     Changes to this file may cause incorrect behavior and will be lost if
//     the code is regenerated.
// </auto-generated>

"""
    
    return header + '\n'.join(lines)
