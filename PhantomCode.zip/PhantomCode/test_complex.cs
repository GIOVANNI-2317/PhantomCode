using System;
using System.Collections.Generic;
using System.Text;

namespace ComplexLibrary
{
    public class DataProcessor
    {
        private readonly int _maxSize;
        private List<string> _processedItems;
        private Dictionary<int, string> _mappings;
        
        public DataProcessor(int maxSize)
        {
            _maxSize = maxSize;
            _processedItems = new List<string>();
            _mappings = new Dictionary<int, string>();
            Initialize();
        }
        
        // Public interface that will remain unchanged
        public string ProcessData(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return string.Empty;
            }
            
            if (_processedItems.Count >= _maxSize)
            {
                ClearOldItems();
            }
            
            string result = TransformInput(input);
            _processedItems.Add(result);
            
            return result;
        }
        
        // Public method to get stats - will remain unchanged
        public Dictionary<string, int> GetStatistics()
        {
            var stats = new Dictionary<string, int>
            {
                { "ProcessedCount", _processedItems.Count },
                { "MaxSize", _maxSize }
            };
            
            return stats;
        }
        
        // Private initialization method - should be renamed
        private void Initialize()
        {
            for (int i = 0; i < 10; i++)
            {
                _mappings[i] = $"Value_{i}";
            }
        }
        
        // Private helper method - should be renamed
        private string TransformInput(string input)
        {
            var builder = new StringBuilder();
            
            foreach (char c in input)
            {
                if (char.IsLetter(c))
                {
                    builder.Append(char.ToUpper(c));
                }
                else if (char.IsDigit(c))
                {
                    int digit = int.Parse(c.ToString());
                    if (_mappings.ContainsKey(digit))
                    {
                        builder.Append(_mappings[digit]);
                    }
                    else
                    {
                        builder.Append(c);
                    }
                }
                else
                {
                    builder.Append('_');
                }
            }
            
            return builder.ToString();
        }
        
        // Private cleanup method - should be renamed
        private void ClearOldItems()
        {
            if (_processedItems.Count > _maxSize / 2)
            {
                _processedItems.RemoveRange(0, _processedItems.Count / 2);
            }
        }
    }
}