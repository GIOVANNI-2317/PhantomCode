import os
import logging
import uuid
import re
from flask import Flask, render_template, request, flash, redirect, url_for, send_from_directory, session
from werkzeug.utils import secure_filename
from utils import obfuscate_csharp_code

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

# Configure upload settings
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'output'
ALLOWED_EXTENSIONS = {'cs', 'txt'}
MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50MB max

# Create upload and output directories if they don't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_csharp_code(code):
    """Basic validation for C# code"""
    # Check for common C# patterns
    if not code or len(code) < 10:
        return False
        
    # Check for common C# keywords and patterns
    csharp_patterns = [
        r'using\s+[\w\.]+;',
        r'namespace\s+[\w\.]+',
        r'class\s+\w+',
        r'public|private|protected|internal',
        r'void|int|string|bool|double|float'
    ]
    
    pattern_matches = 0
    for pattern in csharp_patterns:
        if re.search(pattern, code):
            pattern_matches += 1
            
    # If we match at least 2 patterns, it's likely C# code
    return pattern_matches >= 2

@app.route('/')
def index():
    # Get the last obfuscation data from session if available
    last_obfuscation = session.get('last_obfuscation', None)
    return render_template('index.html', last_obfuscation=last_obfuscation)

@app.route('/upload', methods=['POST'])
def upload_file():
    # Get output format and file name from the form
    output_format = request.form.get('output_format', 'source')
    output_name = request.form.get('output_name', '').strip() or 'ObfuscatedCode'
    
    # Log format selection
    logger.debug(f"Selected output format: {output_format}")
    
    # Get obfuscation options from the form
    obfuscation_options = {
        'rename_private': request.form.get('rename_private', 'off') == 'on',
        'add_dummy_classes': request.form.get('add_dummy_classes', 'off') == 'on',
        'auto_fix_errors': request.form.get('auto_fix_errors', 'off') == 'on',
        'rename_pattern': request.form.get('rename_pattern', 'confusing'),
        'obfuscation_level': request.form.get('obfuscation_level', 'medium'),
        'output_format': output_format,
        # Derivati dal livello di offuscamento
        'obfuscate_strings': request.form.get('obfuscation_level', 'medium') != 'low',
        'obfuscate_control_flow': request.form.get('obfuscation_level', 'medium') == 'high',
        'add_metadata_comments': request.form.get('obfuscation_level', 'medium') == 'high',
    }
    
    # Log options for debugging
    logger.debug(f"Obfuscation options: {obfuscation_options}")
    
    # Check if code is provided in the textarea
    code_input = request.form.get('code_input', '').strip()
    if code_input:
        # Validate the C# code
        if not validate_csharp_code(code_input):
            flash('The provided code does not appear to be valid C# code.', 'danger')
            return redirect(url_for('index'))
            
        # Save the code to a temporary file
        input_id = str(uuid.uuid4())
        input_filename = f"{input_id}_input.cs"
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], input_filename)
        
        with open(input_path, 'w', encoding='utf-8') as f:
            f.write(code_input)
            
        original_filename = 'code_input.cs'
    else:
        # Check if a file was uploaded
        if 'code_file' not in request.files:
            flash('No code provided. Please either upload a file or paste code in the text area.', 'danger')
            return redirect(url_for('index'))
        
        file = request.files['code_file']
        
        if file.filename == '':
            flash('No file selected', 'danger')
            return redirect(url_for('index'))
        
        if not file or not allowed_file(file.filename):
            flash('Invalid file type. Only .cs and .txt files are allowed.', 'danger')
            return redirect(url_for('index'))
        
        # Create a unique filename to avoid collisions
        input_id = str(uuid.uuid4())
        input_filename = f"{input_id}_{secure_filename(file.filename)}"
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], input_filename)
        
        file.save(input_path)
        logger.debug(f"File saved to {input_path}")
        
        # Read the file content to validate
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
            code_content = f.read()
            
        if not validate_csharp_code(code_content):
            os.remove(input_path)
            flash('The uploaded file does not appear to contain valid C# code.', 'danger')
            return redirect(url_for('index'))
            
        original_filename = file.filename
    
    try:
        # Process the code
        output_result = obfuscate_csharp_code(
            input_path, 
            app.config['OUTPUT_FOLDER'], 
            output_name,
            obfuscation_options
        )
        
        if output_result:
            output_path, obfuscated_code, is_dll = output_result
            output_filename = os.path.basename(output_path)
            
            # Store obfuscation details in session
            # Store code preview in a file instead of in session to avoid large cookie size
            preview_id = str(uuid.uuid4())
            preview_path = os.path.join(app.config['OUTPUT_FOLDER'], f"{preview_id}_preview.txt")
            with open(preview_path, 'w', encoding='utf-8') as f:
                f.write(obfuscated_code)
                
            session['last_obfuscation'] = {
                'output_filename': output_filename,
                'original_filename': original_filename,
                'output_name': output_name,
                'options': obfuscation_options,
                'preview_id': preview_id,
                'is_dll': is_dll,
                'timestamp': str(uuid.uuid4())[:8]  # Generate a unique ID for this operation
            }
            
            flash('Code successfully obfuscated! You can now view and download the results.', 'success')
            return redirect(url_for('download_page'))
        else:
            flash('Unable to obfuscate the code. Please try again with valid C# code.', 'danger')
            return redirect(url_for('index'))
            
    except Exception as e:
        logger.error(f"Error during processing: {str(e)}")
        flash(f'An error occurred: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.route('/download-page')
@app.route('/download')  # Add this alternative route for compatibility
def download_page():
    # Get the data from the last obfuscation
    last_obfuscation = session.get('last_obfuscation')
    
    # If there's no obfuscation data, redirect to home
    if not last_obfuscation:
        flash('No obfuscated code available for download.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('download.html', last_obfuscation=last_obfuscation)

@app.route('/download/<filename>')
def download_file(filename):
    # Update session to indicate that the file has been downloaded
    if 'last_obfuscation' in session and session['last_obfuscation'].get('output_filename') == filename:
        session['last_obfuscation']['downloaded'] = True
    
    # Get custom filename if available and add appropriate extension
    custom_name = 'ObfuscatedCode.cs'
    
    if 'last_obfuscation' in session:
        # Check if it's a DLL
        is_dll = session['last_obfuscation'].get('is_dll', False)
        
        # Get the base output name 
        if 'output_name' in session['last_obfuscation']:
            base_name = session['last_obfuscation']['output_name']
            # Strip any extension
            if '.' in base_name:
                base_name = base_name.rsplit('.', 1)[0]
            
            # Add the appropriate extension based on output type
            custom_name = f"{base_name}.{'dll' if is_dll else 'cs'}"
        else:
            custom_name = 'ObfuscatedCode.dll' if is_dll else 'ObfuscatedCode.cs'
    
    # Serve the file
    response = send_from_directory(
        app.config['OUTPUT_FOLDER'], 
        filename, 
        as_attachment=True,
        download_name=custom_name
    )
    
    # Show message after download
    is_dll = session['last_obfuscation'].get('is_dll', False) if 'last_obfuscation' in session else False
    file_type = 'DLL' if is_dll else 'C# code'
    flash(f'Your obfuscated {file_type} has been downloaded. You can process another file or reuse the same settings.', 'success')
    
    return response

@app.route('/preview/<preview_id>')
def get_code_preview(preview_id):
    """Render the code preview from the saved file"""
    preview_path = os.path.join(app.config['OUTPUT_FOLDER'], f"{preview_id}_preview.txt")
    
    if not os.path.exists(preview_path):
        return "// Preview not available", 404
        
    try:
        with open(preview_path, 'r', encoding='utf-8') as f:
            code_content = f.read()
            
        # Get first 1000 chars and last 500 chars for preview
        preview_code = ""
        if len(code_content) > 1500:
            preview_code = code_content[:1000] + "\n...\n" + code_content[-500:]
        else:
            preview_code = code_content
            
        return preview_code
    except Exception as e:
        logger.error(f"Error reading preview: {str(e)}")
        return "// Error loading preview", 500

@app.route('/reuse-settings', methods=['POST'])
def reuse_settings():
    # Check if there's a previous obfuscation
    if 'last_obfuscation' not in session:
        flash('No previous obfuscation settings available.', 'warning')
        return redirect(url_for('index'))
    
    # Get previous options
    previous_options = session['last_obfuscation']['options']
    
    # Get the previous options
    previous_format = session['last_obfuscation']['options'].get('output_format', 'source')
    
    # Get output file name from the form or reuse the previous one
    output_name = request.form.get('output_name', '').strip() or session['last_obfuscation'].get('output_name', 'ObfuscatedCode')
    
    # Remove any extension from the output name
    if '.' in output_name:
        output_name = output_name.rsplit('.', 1)[0]
    
    # Check if code is provided in the textarea
    code_input = request.form.get('code_input', '').strip()
    if code_input:
        # Validate the C# code
        if not validate_csharp_code(code_input):
            flash('The provided code does not appear to be valid C# code.', 'danger')
            return redirect(url_for('index'))
            
        # Save the code to a temporary file
        input_id = str(uuid.uuid4())
        input_filename = f"{input_id}_input.cs"
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], input_filename)
        
        with open(input_path, 'w', encoding='utf-8') as f:
            f.write(code_input)
            
        original_filename = 'code_input.cs'
    else:
        # Check if a file was uploaded (supporting both code_file and dll_file for backward compatibility)
        file = None
        if 'code_file' in request.files and request.files['code_file'].filename:
            file = request.files['code_file']
        elif 'dll_file' in request.files and request.files['dll_file'].filename:
            file = request.files['dll_file']
        
        if not file:
            flash('No code provided. Please either upload a file or paste code in the text area.', 'danger')
            return redirect(url_for('index'))
        
        if file.filename == '':
            flash('No file selected', 'danger')
            return redirect(url_for('index'))
        
        if not allowed_file(file.filename):
            flash('Invalid file type. Only .cs and .txt files are allowed.', 'danger')
            return redirect(url_for('index'))
        
        # Create a unique filename
        input_id = str(uuid.uuid4())
        input_filename = f"{input_id}_{secure_filename(file.filename)}"
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], input_filename)
        
        file.save(input_path)
        logger.debug(f"File saved to {input_path}")
        
        # Read the file content to validate
        with open(input_path, 'r', encoding='utf-8', errors='ignore') as f:
            code_content = f.read()
            
        if not validate_csharp_code(code_content):
            os.remove(input_path)
            flash('The uploaded file does not appear to contain valid C# code.', 'danger')
            return redirect(url_for('index'))
            
        original_filename = file.filename
    
    try:
        # Process the code with previous settings
        output_result = obfuscate_csharp_code(
            input_path, 
            app.config['OUTPUT_FOLDER'], 
            output_name,
            previous_options
        )
        
        if output_result:
            output_path, obfuscated_code, is_dll = output_result
            output_filename = os.path.basename(output_path)
            
            # Store code preview in a file instead of in session to avoid large cookie size
            preview_id = str(uuid.uuid4())
            preview_path = os.path.join(app.config['OUTPUT_FOLDER'], f"{preview_id}_preview.txt")
            with open(preview_path, 'w', encoding='utf-8') as f:
                f.write(obfuscated_code)
                
            # Update the session
            session['last_obfuscation'] = {
                'output_filename': output_filename,
                'original_filename': original_filename,
                'output_name': output_name,
                'options': previous_options,
                'preview_id': preview_id,
                'is_dll': is_dll,
                'timestamp': str(uuid.uuid4())[:8]
            }
            
            flash('Code successfully obfuscated using previous settings!', 'success')
            return redirect(url_for('download_page'))
        else:
            flash('Unable to obfuscate the code. Please try again with valid C# code.', 'danger')
            return redirect(url_for('index'))
            
    except Exception as e:
        logger.error(f"Error during processing: {str(e)}")
        flash(f'An error occurred: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.errorhandler(413)
def too_large(e):
    flash('File is too large. Maximum size is 50MB.', 'danger')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
